# Documentation

Here you will find the full documentation of two components of nRF Connect app:

- [Automated tests](Automated%20tests/README.md)
- [Macros](Macros/README.md)

